import React from "react";
import './App.css'
import logo from './assets/쿼치회식.png'

function App(){
  const title = "명함";
  return(
    <div className="profile-card">
      <div>
        <img src={logo} width="100" alt="쿼치회식" /></div>
      <h1 style={{color : "blue", fontWeight: "bold"}}>김쿼치</h1>
      <p className="content">안녕하세요, 리엑트 개발자입니다.</p>
      <p className="content">저는 리엑트를 좋아합니다.</p>
      <br/>
    <div style={{color : "red"}}>저는 사실 백엔드가 하고 싶어요.</div>
    </div>
  );
}

  export default App;
